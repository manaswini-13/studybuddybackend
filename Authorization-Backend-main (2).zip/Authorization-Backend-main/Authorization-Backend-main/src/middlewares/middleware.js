const authMiddleware = (req, res, next) => {
  
  if (!req.user) {

  }
  next();
};