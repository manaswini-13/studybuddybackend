import mongoose from "mongoose";
import { updateStudentStreak } from "../controllers/streak.controller.js";
const studentStreakSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Student",
      required: true,
      unique: true
    },
    currentStreak: {
      type: Number,
      default: 0
    },
    longestStreak: {
      type: Number,
      default: 0
    },
    lastAttemptDate: {
      type: Date
    }
  },
  { timestamps: true }
);

export const StudentStreak = mongoose.model("StudentStreak", studentStreakSchema);
