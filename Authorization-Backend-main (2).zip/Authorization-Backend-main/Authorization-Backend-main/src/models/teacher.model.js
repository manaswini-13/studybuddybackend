import mongoose, { Schema } from "mongoose";
import brcypt from "bcrypt"


const TeacherSchema = new Schema({

    college: {
        type: String,
        required:true
    },
    
    email: {
        type: String,
        require: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    password: {
        type: String,
        required: [true, "password is required"]
    },
    forgotPasswordToken: {
        type: String
    },
    forgotPasswordExpiry: {
        type: Date
    },
    students: {type:'ObjectId', ref:'Student'},
    parents: {type:'ObjectId', ref:'Parent'}
}, {
    timestamps: true,
},
)

TeacherSchema.pre("save", async function (next) {
    if (!this.isModified("password")) return next()

    this.password = await brcypt.hash(this.password, 10)
    next()
})

TeacherSchema.methods.isPasswordCorrect = async function (password) {
    return await brcypt.compare(password, this.password)
};


export const Teacher = mongoose.model("Teacher", TeacherSchema)
export default Teacher;
