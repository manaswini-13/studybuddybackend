import mongoose, { Schema } from "mongoose";
import bcrypt from "bcrypt"


const StudentSchema = new Schema({
    college: {
        type: String,
        required:true
    },
    
    username: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        index: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    fullname: {
        type: String,
        trim: true
    },
    password: {
        type: String,
        required: [true, "password is required"]
    },
    forgotPasswordToken: {
        type: String
    },
    forgotPasswordExpiry: {
        type: Date
    },
   teacherEmail: {type: String} ,
   teacherId: mongoose.Schema.Types.ObjectId
}, {
    timestamps: true,
},
)

StudentSchema.pre("save", async function (next) {
    if (!this.isModified("password")) return next()
    this.password = await bcrypt.hash(this.password, 10)
    next()
})

StudentSchema.methods.isPasswordCorrect = async function (password) {
    return await bcrypt.compare(password, this.password)
};


export const Student = mongoose.model("Student", StudentSchema)
export default Student;