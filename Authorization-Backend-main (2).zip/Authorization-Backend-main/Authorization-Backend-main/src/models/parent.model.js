import mongoose, { Schema } from "mongoose";

const ParentSchema = new Schema({
    code: {
        type: String
    },
    children: {type:'ObjectId', ref:'Student'}
}, 
{
    timestamps: true
})

export const Parent = mongoose.model("Parent", ParentSchema)
