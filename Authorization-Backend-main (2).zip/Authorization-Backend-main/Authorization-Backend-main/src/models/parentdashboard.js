import mongoose from "mongoose";

const parentDashboardSchema = new mongoose.Schema(
  {
    parentEmail: { type: String, required: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },

    progress: {
      totalQuizzes: { type: Number, default: 0 },
      averageScore: { type: Number, default: 0 },
      bestScore: { type: Number, default: 0 },
    },

    marks: [
      {
        quizId: { type: mongoose.Schema.Types.ObjectId, required: true },
        score: Number,
        type: String,
        createdAt: Date
      }
    ]
  },
  { timestamps: true }
);

export const ParentDashboard = mongoose.model("ParentDashboard", parentDashboardSchema);
export default ParentDashboard;