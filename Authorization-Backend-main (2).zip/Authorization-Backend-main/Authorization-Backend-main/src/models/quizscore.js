import mongoose from "mongoose";
import { updateStudentStreak } from "../controllers/streak.controller.js";

const quizScheduleSchema = new mongoose.Schema(
  {
    quizId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Quiz", // or "QuizAnswer" or whatever your quiz model is
      required: true,
    },
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Teacher",
      required: true,
    },
    title: {
      type: String,
      required: true, // e.g. "Chapter 2 Algebra Test"
      trim: true,
    },
    description: {
      type: String,
      trim: true,
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    status: {
      type: String,
      enum: ["SCHEDULED", "ACTIVE", "COMPLETED", "CANCELLED"],
      default: "SCHEDULED",
    },
  },
  { timestamps: true }
);

export const QuizSchedule = mongoose.model("QuizSchedule", quizScheduleSchema);

const quizAnswerSchema = new mongoose.Schema(
  {
    quizId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      index: true,
    },
    correctAnswers: {
      type: Object,
      required: true,
    },
    type: {
      type: String,
      enum: ["SELF", "ASSIGNED"], 
      required: true,
    },
    isTemporary: {
      type: Boolean,
      default: false, 
    },
    teacher: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: function () {
        return this.type === "ASSIGNED";
      },
    },
  },
  { timestamps: true }
);

const QuizAnswer = mongoose.model("QuizAnswer", quizAnswerSchema);

const quizSubmissionSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    quizId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
    },
    submittedAnswers: {
      type: Object,
      required: true,
    },
    score: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

const QuizSubmission = mongoose.model("QuizSubmission", quizSubmissionSchema);


const gradeQuiz = (correctAnswers, submittedAnswers) => {
  let score = 0;

  for (const qid in correctAnswers) {
    if (
      Object.prototype.hasOwnProperty.call(submittedAnswers, qid) &&
      submittedAnswers[qid] == correctAnswers[qid]
    ) {
      score++;
    }
  }

  return score;
};

const submitSelfAssessment = async (req, res) => {
  const { quizId, submittedAnswers, correctAnswers, studentId } = req.body;

  if (!quizId || !submittedAnswers || !correctAnswers || !studentId) {
    return res.status(400).json({
      message:
        "quizId, submittedAnswers, correctAnswers, and studentId are required",
    });
  }

  let submissionRecord = null;
  let answerKeyRecord = null;

  try {
    answerKeyRecord = await QuizAnswer.create({
      quizId,
      correctAnswers,
      type: "SELF",
      isTemporary: true,
    });

    const score = gradeQuiz(correctAnswers, submittedAnswers);

    submissionRecord = await QuizSubmission.create({
      student: studentId,
      quizId,
      submittedAnswers,
      score,
    });

    return res.status(200).json({
      message: "Self-assessment graded successfully",
      score,
    });
  } catch (error) {
    console.error("Error submitting self-assessment:", error);
    return res.status(500).json({ message: "Internal server error" });
  } finally {
    try {
      if (submissionRecord?._id) {
        await QuizSubmission.findByIdAndDelete(submissionRecord._id);
      }
      if (answerKeyRecord?._id) {
        await QuizAnswer.findByIdAndDelete(answerKeyRecord._id);
      }
    } catch (cleanupError) {
      console.error("Cleanup error (self-assessment):", cleanupError);
    }
  }
};

const submitTeacherAssignedQuiz = async (req, res) => {
  const { quizId, submittedAnswers, studentId, studentEmail } = req.body;

  if (!quizId || !submittedAnswers || !studentId || !studentEmail) {
    return res.status(400).json({
      message:
        "quizId, submittedAnswers, studentId, and studentEmail are required",
    });
  }
  await updateStudentStreak(studentId);


  try {
    
    const answerKey = await QuizAnswer.findOne({
      quizId,
      type: "ASSIGNED",
    });

    if (!answerKey) {
      return res.status(404).json({
        message:
          "Quiz answer key not found or has been terminated. Make sure the teacher created an ASSIGNED answer key for this quizId.",
      });
    }

    
    const score = gradeQuiz(answerKey.correctAnswers, submittedAnswers);

    
    const scoreDoc = await QuizScore.create({
      studentEmail,
      student: studentId,
      quizId,
      score,
      type: "ASSIGNED",
      submittedAnswers,
    });

    return res.status(200).json({
      message: "Teacher-assigned quiz graded successfully",
      score,
      scoreId: scoreDoc._id,
    });
  } catch (error) {
    console.error("Error submitting teacher-assigned quiz:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const createOrUpdateAssignedAnswerKey = async (req, res) => {
  const { quizId, correctAnswers, teacherId } = req.body;

  if (!quizId || !correctAnswers || !teacherId) {
    return res.status(400).json({
      message: "quizId, correctAnswers, and teacherId are required",
    });
  }

  try {
    const answerKey = await QuizAnswer.findOneAndUpdate(
      { quizId, type: "ASSIGNED", teacher: teacherId },
      {
        quizId,
        correctAnswers,
        type: "ASSIGNED",
        isTemporary: false,
        teacher: teacherId,
      },
      { upsert: true, new: true }
    );

    return res.status(200).json({
      message: "Assigned quiz answer key saved successfully",
      answerKey,
    });
  } catch (error) {
    console.error("Error creating/updating assigned answer key:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const terminateAssignedQuiz = async (req, res) => {
  const { quizId, teacherId } = req.body;

  if (!quizId || !teacherId) {
    return res
      .status(400)
      .json({ message: "quizId and teacherId are required" });
  }

  try {
    const deleted = await QuizAnswer.findOneAndDelete({
      quizId,
      type: "ASSIGNED",
      teacher: teacherId,
    });

    if (!deleted) {
      return res.status(404).json({
        message: "No active assigned quiz found for this teacher and quiz",
      });
    }

    return res.status(200).json({
      message: "Assigned quiz terminated successfully",
    });
  } catch (error) {
    console.error("Error terminating quiz:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
const quizScoreSchema = new mongoose.Schema(
  {
    studentEmail: {
      type: String,
      required: true,
      index: true,
    },
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    quizId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      index: true,
    },
    score: {
      type: Number,
      required: true,
    },
    type: {
      type: String,
      enum: ["SELF", "ASSIGNED"], 
      required: true,
    },
    submittedAnswers: {
      type: Object,
      required: true, 
    },
  },
  { timestamps: true }
);
const getStudentQuizDetails = async (req, res) => {
  const { quizId, studentEmail, studentId } = req.body;

  
  if (!quizId || (!studentEmail && !studentId)) {
    return res.status(400).json({
      message: "quizId and either studentEmail or studentId are required",
    });
  }

  try {
    const query = { quizId };

    if (studentEmail) {
      query.studentEmail = studentEmail;
    }

    if (studentId) {
      query.student = studentId;
    }

    
    const scores = await QuizScore.find(query).sort({ createdAt: 1 });

    if (!scores.length) {
      return res.status(404).json({
        message: "No scores found for this quiz and student",
      });
    }

    
    const latestAttempt = scores[scores.length - 1];

    return res.status(200).json({
      message: "Quiz details fetched successfully",
      quizId,
      attemptsCount: scores.length,
      latestScore: latestAttempt.score,
      latestType: latestAttempt.type, // "SELF" or "ASSIGNED"
      latestAttemptAt: latestAttempt.createdAt,
      attempts: scores, 
    });
  } catch (error) {
    console.error("Error fetching quiz details for student:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};


const QuizScore = mongoose.model("QuizScore", quizScoreSchema);

const getQuizDetailsForTeacher = async (req, res) => {
  const { quizId, teacherId } = req.body;

  if (!quizId || !teacherId) {
    return res.status(400).json({
      message: "quizId and teacherId are required",
    });
  }

  try {

    const answerKey = await QuizAnswer.findOne({
      quizId,
      type: "ASSIGNED",
      teacher: teacherId,
    });

    if (!answerKey) {
      return res.status(404).json({
        message:
          "No ASSIGNED quiz found for this teacher and quizId. Make sure the teacher created the quiz.",
      });
    }

    
    const scores = await QuizScore.find({
      quizId,
      type: "ASSIGNED",
    })
      .sort({ createdAt: 1 }) 
      .lean();

    if (!scores.length) {
      return res.status(404).json({
        message: "No student scores found for this quiz yet",
      });
    }

    
    const studentsCount = scores.length;

    return res.status(200).json({
      message: "Quiz details fetched successfully",
      quizId,
      teacherId,
      studentsCount,
      results: scores,
    });
  } catch (error) {
    console.error("Error fetching quiz details for teacher:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getQuizLeaderboard = async (req, res) => {
  const { quizId, type, limit } = req.body;

  if (!quizId) {
    return res.status(400).json({
      message: "quizId is required",
    });
  }

  if (!mongoose.Types.ObjectId.isValid(quizId)) {
    return res.status(400).json({
      message: "Invalid quizId format",
    });
  }


  const quizType = type || "ASSIGNED";
  const maxResults = limit && Number(limit) > 0 ? Number(limit) : 50;

  try {
    const leaderboard = await QuizScore.aggregate([
      {
        $match: {
          quizId: new mongoose.Types.ObjectId(quizId),
          type: quizType, // "ASSIGNED" or "SELF"
        },
      },
      
      {
        $sort: {
          score: -1,
          createdAt: 1,
        },
      },
      
      {
        $group: {
          _id: {
            student: "$student",
            studentEmail: "$studentEmail",
          },
          bestScore: { $first: "$score" },
          attemptsCount: { $sum: 1 },
          lastAttemptAt: { $max: "$createdAt" },
        },
      },
      
      {
        $project: {
          _id: 0,
          student: "$_id.student",
          studentEmail: "$_id.studentEmail",
          bestScore: 1,
          attemptsCount: 1,
          lastAttemptAt: 1,
        },
      },
      
      {
        $sort: {
          bestScore: -1,
          lastAttemptAt: 1,
        },
      },
      {
        $limit: maxResults,
      },
    ]);

    if (!leaderboard.length) {
      return res.status(404).json({
        message: "No scores found for this quiz",
      });
    }

    return res.status(200).json({
      message: "Leaderboard fetched successfully",
      quizId,
      type: quizType,
      totalStudents: leaderboard.length,
      leaderboard,
    });
  } catch (error) {
    console.error("Error fetching leaderboard:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
const getStudentQuizStats = async (req, res) => {
  const { studentId } = req.body;

  if (!studentId) {
    return res.status(400).json({
      message: "studentId is required",
    });
  }

  try {
    
    const scores = await QuizScore.find({ student: studentId });

    if (!scores.length) {
      return res.status(404).json({
        message: "No quiz attempts found for this student",
        totalQuizzesAttempted: 0,
        averageScore: 0,
      });
    }

    
    const totalQuizzesAttempted = scores.length;

    
    const totalScore = scores.reduce((sum, record) => sum + record.score, 0);
    const averageScore = totalScore / totalQuizzesAttempted;

    return res.status(200).json({
      message: "Student quiz statistics fetched successfully",
      studentId,
      totalQuizzesAttempted,
      averageScore: Number(averageScore.toFixed(2)), 
      attempts: scores, 
    });
  } catch (error) {
    console.error("Error fetching student quiz stats:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

export {
  QuizAnswer,
  QuizSubmission,
  QuizScore,
  gradeQuiz,
  submitSelfAssessment,
  submitTeacherAssignedQuiz,
  terminateAssignedQuiz,
  createOrUpdateAssignedAnswerKey,
  getStudentQuizDetails,
    getQuizDetailsForTeacher,
    getQuizLeaderboard,
    getStudentQuizStats,
};
