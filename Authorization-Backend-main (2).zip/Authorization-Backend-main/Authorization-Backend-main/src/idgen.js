
function generateTwoLetterString() {
  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let result = "";
  result += letters[Math.floor(Math.random() * letters.length)];
  result += letters[Math.floor(Math.random() * letters.length)];
  return result;
}


function generateThreeDigitNumber() {
  return Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, "0");
}


export function generateStudentId() {
  const letters = generateTwoLetterString();
  const digits = generateThreeDigitNumber();
  return `ST-${letters}${digits}`;
}
export function generateTeacherId() {
  const letters = generateTwoLetterString();
  const digits = generateThreeDigitNumber();
  return `TC-${letters}${digits}`;
}

