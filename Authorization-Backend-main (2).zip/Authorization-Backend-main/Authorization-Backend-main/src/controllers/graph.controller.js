import { QuizScore } from "../models/quizscore.js";

export const getStudentScoreGraph = async (req, res) => {
  const { studentEmail } = req.body;

  const scores = await QuizScore.find({ studentEmail }).sort({ createdAt: 1 });

  return res.status(200).json({
    labels: scores.map(s => s.createdAt.toDateString()),
    data: scores.map(s => s.score)
  });
};

export const getTeacherClassGraph = async (req, res) => {
  const { teacherEmail } = req.body;

  const students = await Student.find({ teacherEmail });

  let dataset = [];

  for (const student of students) {
    const scores = await QuizScore.find({ studentEmail: student.email });
    const avg =
      scores.length > 0
        ? scores.reduce((a, b) => a + b.score, 0) / scores.length
        : 0;

    dataset.push({
      name: student.name,
      avgScore: avg
    });
  }

  return res.status(200).json({ dataset });
};
