import { Teacher } from "../models/teacher.model.js";

export const createOrUpdateTeacherProfile = async (req, res) => {
  const {
    teacherId,
    email,            
    name,
    subject,
    bio,
  } = req.body;

  if (!teacherId && !email) {
    return res.status(400).json({
      message: "teacherId or email is required to update profile",
    });
  }

  try {
    const query = {};

    if (teacherId) {
      query._id = teacherId;
    }

    if (email) {
      query.email = email;
    }


    const update = {};
    if (name !== undefined) update.name = name;
    if (subject !== undefined) update.subject = subject;
    if (bio !== undefined) update.bio = bio;

    const teacher = await Teacher.findOneAndUpdate(
      query,
      { $set: update },
      {
        new: true,   
        upsert: false, 
      }
    ).lean();

    if (!teacher) {
      return res.status(404).json({
        message: "Teacher not found",
      });
    }

    
    const { password, ...safeProfile } = teacher;

    return res.status(200).json({
      message: "Teacher profile saved successfully",
      profile: safeProfile,
    });
  } catch (error) {
    console.error("Error saving teacher profile:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};


export const getTeacherProfile = async (req, res) => {
  const { teacherId, email } = req.body;

  if (!teacherId && !email) {
    return res.status(400).json({
      message: "teacherId or email is required to fetch profile",
    });
  }

  try {
    const query = {};

    if (teacherId) {
      query._id = teacherId;
    }

    if (email) {
      query.email = email;
    }

    const teacher = await Teacher.findOne(query).lean();

    if (!teacher) {
      return res.status(404).json({
        message: "Teacher not found",
      });
    }

    const { password, ...safeProfile } = teacher;

    return res.status(200).json({
      message: "Teacher profile fetched successfully",
      profile: safeProfile,
    });
  } catch (error) {
    console.error("Error fetching teacher profile:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
