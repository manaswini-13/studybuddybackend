import { generateStudentId, generateTeacherId } from "../utils/idgen.js";

const newStudentId = generateStudentId();
console.log("Generated Student ID:", newStudentId);

const newTeacherId = generateTeacherId();
console.log("Generated Teacher ID:", newTeacherId);
