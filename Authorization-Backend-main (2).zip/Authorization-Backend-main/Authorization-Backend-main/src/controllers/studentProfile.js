import Student from "../models/student.models.js";

export const getStudentProfile = async (req, res) => {
  const { studentId, email } = req.body;

  if (!studentId && !email) {
    return res.status(400).json({
      message: "studentId or email is required to fetch profile",
    });
  }

  try {
    const query = {};

    if (studentId) {
      query._id = studentId;
    }

    if (email) {
      query.email = email;
    }

    const student = await Student.findOne(query).lean();

    if (!student) {
      return res.status(404).json({
        message: "Student not found",
      });
    }

    const {password , ...safeProfile } = student;

    return res.status(200).json({
      message: "Student profile fetched successfully",
      profile: safeProfile,
    });
  } catch (error) {
    console.error("Error fetching student profile:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

