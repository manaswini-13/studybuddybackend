import { Student } from "../models/student.models.js"; 
import { Teacher } from "../models/teacher.model.js";

export const countStudentsUnderTeacher = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        message: "email is required",
      });
    }

   
    const teacher = await Teacher.findOne({ email: email });

    if (!teacher) {
      return res.status(404).json({
        message: "No teacher found with that email",
      });
    }

    
    const totalStudents = await Student.countDocuments({
      email: email, 
    });

    return res.status(200).json({
      message: "Student count fetched successfully",
      email,
      totalStudents,
    });

  } catch (error) {
    console.error("Error counting students:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
};
