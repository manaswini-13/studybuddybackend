import { QuizScore } from "../models/quizscore.js";
import { ParentDashboard } from "../models/parentDashboard.model.js";
import { Student } from "../models/student.models.js";

export const getParentDashboard = async (req, res) => {
  const { studentEmail } = req.body;

  if (!studentEmail) {
    return res.status(400).json({ message: "studentEmail is required" });
  }

  const student = await Student.findOne({ email: studentEmail });
  if (!student) return res.status(404).json({ message: "Student not found" });

  const scores = await QuizScore.find({ studentEmail });

  const total = scores.length;
  const avg = total ? scores.reduce((a, b) => a + b.score, 0) / total : 0;
  const best = total ? Math.max(...scores.map(s => s.score)) : 0;

  const dashboard = await ParentDashboard.findOneAndUpdate(
    { parentEmail: req.body.parentEmail, student: student._id },
    {
      progress: {
        totalQuizzes: total,
        averageScore: avg,
        bestScore: best
      },
      marks: scores
    },
    { new: true, upsert: true }
  );

  return res.status(200).json({
    message: "Parent dashboard ready",
    dashboard
  });
};
