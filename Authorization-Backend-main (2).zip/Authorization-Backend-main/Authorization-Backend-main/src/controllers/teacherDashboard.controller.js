import { Student } from "../models/student.models.js";
import { QuizScore } from "../models/quizscore.js";

export const getTeacherDashboard = async (req, res) => {
  const { teacherEmail } = req.body;

  if (!teacherEmail) {
    return res.status(400).json({ message: "teacherEmail is required" });
  }

  const students = await Student.find({ teacherEmail });

  const result = [];

  for (const student of students) {
    const scores = await QuizScore.find({ studentEmail: student.email });

    const lastScore = scores.length ? scores[scores.length - 1].score : null;

    // Weak topics → wrong answers
    let topicMap = {};

    scores.forEach(score => {
      Object.entries(score.submittedAnswers).forEach(([q, ans]) => {
        if (ans !== score.correctAnswers[q]) {
          topicMap[q] = (topicMap[q] || 0) + 1;
        }
      });
    });

    const weakTopics = Object.keys(topicMap).sort(
      (a, b) => topicMap[b] - topicMap[a]
    );

    result.push({
      studentName: student.name,
      studentEmail: student.email,
      lastScore,
      weakTopics,
      dashboardLink: `/student-dashboard/${student._id}`
    });
  }

  return res.status(200).json({
    message: "Teacher dashboard ready",
    students: result
  });
};
