import { StudentStreak } from "../models/studentstreak.js";
import { QuizScore } from "../models/quizscore.js";

export const updateStudentStreak = async (studentId) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let streak = await StudentStreak.findOne({ student: studentId });

  if (!streak) {
    streak = await StudentStreak.create({
      student: studentId,
      currentStreak: 1,
      longestStreak: 1,
      lastAttemptDate: today
    });
    return streak;
  }

  const last = streak.lastAttemptDate;
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  if (!last) {
    streak.currentStreak = 1;
  } else {
    const lastDate = new Date(last);
    lastDate.setHours(0, 0, 0, 0);

    if (lastDate.getTime() === today.getTime()) {
      return streak;
    }

    if (lastDate.getTime() === yesterday.getTime()) {
      streak.currentStreak += 1;
    } else {
      streak.currentStreak = 1;
    }
  }

  streak.lastAttemptDate = today;
  if (streak.currentStreak > streak.longestStreak) {
    streak.longestStreak = streak.currentStreak;
  }

  await streak.save();
  return streak;
};
