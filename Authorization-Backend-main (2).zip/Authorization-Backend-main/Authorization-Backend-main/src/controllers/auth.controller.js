import { Student } from "../models/student.models.js";
import { Teacher } from "../models/teacher.model.js";
import { Parent } from "../models/parent.model.js";
import { ApiResponse } from "../utils/api_response.js";
import { Apierror } from "../utils/api_error.js";
import { asynchandler } from "../utils/async_handler.js";


const RegisterStudent = asynchandler(async (req, res) => {
    if (!req.body) {
        throw new Apierror(400, "Request body is missing");
    }

    const { email, username, password, college } = req.body;

    if (!email || !username || !password || !college ) {
        throw new Apierror(400, "email, username, password, and college are required");
    }

    const existedStudent = await Student.findOne({ $or: [{ username }, { email }] });
    if (existedStudent) {
        throw new Apierror(409, "Student with email or username already exists");
    }

    const student = await Student.create({ college, email, password, username, isEmailVerified: false });

    const { hashedToken, tokenExpiry } = generateTemporaryToken();
    student.emailVerificationExpiry = tokenExpiry;
    student.emailVerificationToken = hashedToken;
    await student.save({ validateBeforeSave: false });

    const createdStudent = await Student.findById(student._id).select("-password -refreshToken -emailVerificationToken -emailVerificationExpiry");
    if (!createdStudent) throw new Apierror(500, "Something went wrong while creating user record");

    return res.status(201).json(new ApiResponse(201, { user: createdStudent }, "Student Registered Successfully"));
});


const RegisterTeacher = asynchandler(async (req, res) => {
    if (!req.body) {
        throw new Apierror(400, "Request body is missing");
    }

    const { email, password, college } = req.body;

    if (!email || !password || !college ) {
        throw new Apierror(400, "email, password, and college are required");
    }
    const existedTeacher = await Teacher.findOne({ $or: [{ email }]});
    if (existedTeacher) {
        throw new Apierror(409, "Teacher with email or username already exists");
    }

    const teacher = await Teacher.create({ college, email, password, isEmailVerified: false });

    const createdTeacher = await Teacher.findById(teacher._id).select("-password -refreshToken");
    if (!createdTeacher) throw new Apierror(500, "Something went wrong while creating teacher record");

    return res.status(201).json(new ApiResponse(201, { user: createdTeacher }, "Teacher Registered Successfully"));
});


const RegisterParent = asynchandler(async (req, res) => {
    if (!req.body) {
        throw new Apierror(400, "Request body is missing");
    }

    const { code } = req.body;

    if (!code ) {
        throw new Apierror(400, "code is required");
    }


    const parent = await Parent.create({ code });

    const createdParent = await Parent.findById(parent._id).select("-password -refreshToken");
    if (!createdParent) throw new Apierror(500, "Something went wrong while creating Parent record");

    return res.status(201).json(new ApiResponse(201, { user: createdParent }, "Parent Registered Successfully"));
});

const loginStudent = asynchandler(async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        throw new Apierror(400, "Email and password are required");
    }

    const user = await Student.findOne({ email }).select('+password');
    
    if (!user) {
        throw new Apierror(400, `Student with email '${email}' does not exist.`);
    }

    const isPassValid = await user.isPasswordCorrect(password);
    if (!isPassValid) {
        throw new Apierror(400, "Invalid Password");
    }

    
    const sessionPart = Math.random().toString(36).substring(2);
    const sessionToken = (new Date().getTime().toString(36)) + sessionPart;
    
    user.refreshToken = sessionToken;
    await user.save({ validateBeforeSave: false });


    const loginUser = await Student.findById(user._id).select("-password -refreshToken -emailVerificationToken -emailVerificationExpiry");

    const options = { httpOnly: true, secure: process.env.NODE_ENV === "production" };
    
    return res.status(200)
        .cookie("sessionId", sessionToken, options)
        .json(new ApiResponse(200, { user: loginUser, role: 'student' }, "Student Logged in successfully"));
});
const loginTeacher = asynchandler(async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        throw new Apierror(400, "Email and password are required");
    }

    const user = await Teacher.findOne({ email }).select('+password');
    
    if (!user) {
        throw new Apierror(400, `Teacher with email '${email}' does not exist.`);
    }


    const isPassValid = await user.isPasswordCorrect(password);
    if (!isPassValid) {
        throw new Apierror(400, "Invalid Password");
    }

  
    const sessionPart = Math.random().toString(36).substring(2);
    const sessionToken = (new Date().getTime().toString(36)) + sessionPart;
    
    user.refreshToken = sessionToken;
    await user.save({ validateBeforeSave: false });

    const loginUser = await Teacher.findById(user._id).select("-password -refreshToken");

    const options = { httpOnly: true, secure: process.env.NODE_ENV === "production" };
    
    return res.status(200)
        .cookie("sessionId", sessionToken, options)
        .json(new ApiResponse(200, { user: loginUser, role: 'teacher' }, "Teacher Logged in successfully"));
});

const loginParent = asynchandler(async (req, res) => {
    const { code } = req.body;

    if (!code) {
        throw new Apierror(400, "Code is required for parent login.");
    }

 
    const user = await Parent.findOne({ code });
    
    if (!user) {
        throw new Apierror(400, "Invalid code or Parent account does not exist.");
    }
    
 
    const sessionPart = Math.random().toString(36).substring(2);
    const sessionToken = (new Date().getTime().toString(36)) + sessionPart;

    user.refreshToken = sessionToken;
    await user.save({ validateBeforeSave: false });


    const loginUser = await Parent.findById(user._id).select("-refreshToken");

    const options = { httpOnly: true, secure: process.env.NODE_ENV === "production" };
    
    return res.status(200)
        .cookie("sessionId", sessionToken, options)
        .json(new ApiResponse(200, { user: loginUser, role: 'parent' }, "Parent Logged in successfully"));
});



const logoutUser = asynchandler(async (req, res) => {

    const userId = req.user?._id; 
    const role = req.user?.role;
    const Model = role === 'student' ? Student : role === 'teacher' ? Teacher : role === 'parent' ? Parent : null;

    if (userId && Model) {
      
        await Model.findByIdAndUpdate(userId, { $set: { refreshToken: "" } }, { new: true });
    }
    
    const options = { httpOnly: true, secure: process.env.NODE_ENV === "production" };
    
    return res.status(200)
       
        .clearCookie("sessionId", options)
        .json(new ApiResponse(200, {}, "User Logged Out"));
});


const getCurrentUser = asynchandler(async (req, res) => {
    if (!req.user) {
         throw new Apierror(401, "User not authenticated");
    }
    return res.status(200).json(new ApiResponse(200, req.user, "Current User Fetched Successfully"));
});

function generateResetToken() {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}



const forgotStudentPassword = async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({
      message: "Email is required",
    });
  }

  try {
    const student = await Student.findOne({ email });


    if (!student) {
      return res.status(200).json({
        message: "If this email is registered, a reset link has been sent.",
      });
    }

    const resetToken = generateResetToken();
    const expiresAt = Date.now() + 60 * 60 * 1000; // 1 hour

    student.resetPasswordToken = resetToken;
    student.resetPasswordExpires = expiresAt;
    await student.save();

    return res.status(200).json({
      message: "Password reset token generated for student.",
      resetToken,
    });
  } catch (error) {
    console.error("Error in forgotStudentPassword:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const forgotTeacherPassword = async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({
      message: "Email is required",
    });
  }

  try {
    const teacher = await Teacher.findOne({ email });

    if (!teacher) {
      return res.status(200).json({
        message: "If this email is registered, a reset link has been sent.",
      });
    }

    // Generate token WITHOUT crypto
    const resetToken = generateResetToken();
    const expiresAt = Date.now() + 60 * 60 * 1000;

    teacher.resetPasswordToken = resetToken;
    teacher.resetPasswordExpires = expiresAt;
    await teacher.save();

    return res.status(200).json({
      message: "Password reset token generated for teacher.",
      resetToken,
    });
  } catch (error) {
    console.error("Error in forgotTeacherPassword:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};






export {
    RegisterStudent,
    RegisterTeacher,
    RegisterParent,
    loginStudent,
    loginTeacher,
    loginParent,
    logoutUser, 
    getCurrentUser,
    forgotStudentPassword,
    forgotTeacherPassword
};