import { QuizSchedule } from "../models/quizscore.js";
import { Apierror } from "../utils/api_error.js";
import { ApiResponse } from "../utils/api_response.js";
import { asynchandler } from "../utils/async_handler.js";


const createScheduledQuiz = asynchandler(async (req, res) => {
    const teacherId = req.user?._id; 
    
    const { quizId, title, startDate, endDate } = req.body;

    if (!quizId || !title || !startDate || !endDate) {
        throw new Apierror(400, "Missing quizId, title, startDate, or endDate.");
    }
    
    if (new Date(startDate) >= new Date(endDate)) {
        throw new Apierror(400, "Start date must be before end date.");
    }
    
    const existingSchedule = await QuizSchedule.findOne({ quizId });
    if (existingSchedule) {
        throw new Apierror(409, `Quiz ID ${quizId} is already scheduled.`);
    }

    const scheduledQuiz = await QuizSchedule.create({
        quizId,
        title,
        teacher: teacherId,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        status: 'SCHEDULED'
    });

    return res.status(201).json(new ApiResponse(201, scheduledQuiz, "Quiz scheduled successfully."));
});


const getClosestQuiz = asynchandler(async (req, res) => {
    const now = new Date();

    const closestQuiz = await QuizSchedule.findOne({
        startDate: { $gt: now }, 
        status: { $in: ['SCHEDULED', 'ACTIVE'] } 
    })
    .sort({ startDate: 1 }) 
    .limit(1) 
    .select('quizId title startDate endDate'); 

    if (!closestQuiz) {
        return res.status(200).json(new ApiResponse(200, null, "No upcoming quizzes found."));
    }

    return res.status(200).json(new ApiResponse(200, closestQuiz, "Closest upcoming quiz fetched successfully."));
});


export { createScheduledQuiz, getClosestQuiz };