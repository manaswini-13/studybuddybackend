import { Router } from "express";
import { RegisterStudent } from "../controllers/auth.controller.js";
import { RegisterTeacher } from "../controllers/auth.controller.js";
import { RegisterParent } from "../controllers/auth.controller.js";
import { loginStudent } from "../controllers/auth.controller.js";
import { loginTeacher } from "../controllers/auth.controller.js";
import { loginParent } from "../controllers/auth.controller.js";
import { submitSelfAssessment } from "../models/quizscore.js";
import { submitTeacherAssignedQuiz } from "../models/quizscore.js";
import { terminateAssignedQuiz } from "../models/quizscore.js";
import { createOrUpdateAssignedAnswerKey } from "../models/quizscore.js";
import { getStudentQuizDetails } from "../models/quizscore.js";
import { getQuizDetailsForTeacher } from "../models/quizscore.js";
import { getQuizLeaderboard } from "../models/quizscore.js";
import { getStudentQuizStats } from "../models/quizscore.js";
import { getStudentProfile } from "../controllers/studentProfile.js";
import { getTeacherProfile, createOrUpdateTeacherProfile } from "../controllers/teacherProfile.js";
import { forgotStudentPassword, forgotTeacherPassword } from "../controllers/auth.controller.js";
import { createScheduledQuiz, getClosestQuiz } from '../controllers/schedule.controller.js';
import { countStudentsUnderTeacher } from '../controllers/teacherStats.controller.js';


const router = Router()


router.route("/register-student").post(RegisterStudent)
router.route("/register-teacher").post(RegisterTeacher)
router.route("/register-parent").post(RegisterParent);
router.route("/login-student").post(loginStudent);
router.route("/login-teacher").post(loginTeacher);
router.route("/login-parent").post(loginParent);
router.post("/self", submitSelfAssessment); //student generated quiz submission
router.post("/assigned", submitTeacherAssignedQuiz); //teacher assigned quiz submission by the student
router.post("/terminate", terminateAssignedQuiz); //terminate assigned quiz by the teacher
router.post("/answer-key", createOrUpdateAssignedAnswerKey); //teacher assigned quiz correct answers by teacher
router.post("/student-quiz", getStudentQuizDetails); //for the student to get their quiz score
router.post("/teacher-quiz", getQuizDetailsForTeacher); //for the teacher to get quiz details of students
router.post("/quiz-leaderboard", getQuizLeaderboard); //to get quiz leaderboard
router.post("/student-quiz-stats", getStudentQuizStats); //to get student's total quizes and average score
router.post("/student-profile", getStudentProfile); //to get student profile on student dashboard
router.post("/teacher-profile", createOrUpdateTeacherProfile); //to create or update teacher dashboard
router.post("/get-teacher-profile", getTeacherProfile); //to get teacher profile on teacher dashboard
router.post("/forgot-password-student", forgotStudentPassword);
router.post("/forgot-password-teacher", forgotTeacherPassword);
router.post("/schedule-quiz", createScheduledQuiz); // Create a new scheduled quiz
router.get("/closest-quiz", getClosestQuiz); // Get the closest upcoming quiz
router.post("/count-students", countStudentsUnderTeacher); // Count students under a specific teacher


export default router;